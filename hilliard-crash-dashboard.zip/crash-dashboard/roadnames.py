#!/usr/bin/env python3
"""
roadnames.py — snap OCR'd road names to a canonical Hilliard road list so hot-spot counts add up.

    python3 roadnames.py data/crashes.json          # rewrites the file in place (also crashes.csv)

Used automatically by batch_worker.py assemble. Add roads to CANON as needed: "NAME": "Type".
"""
import difflib, json, re, sys, os

CANON = {
    "CEMETERY": "Road", "MAIN": "Street", "DAVIDSON": "Road", "LEAP": "Road", "TRUEMAN": "Boulevard", "BRITTON": "Parkway",
    "SCIOTO DARBY": "Road", "HILLIARD ROME": "Road", "WILCOX": "Road", "NORWICH": "Street", "HAYDEN RUN": "Road", "AVERY": "Road",
    "RIGGINS": "Road", "LEPPERT": "Road", "LACON": "Road", "DUBLIN": "Road", "ALTON DARBY CREEK": "Road", "MILL RUN": "Drive",
    "ROBERTS": "Road", "LYMAN": "Drive", "TINAPPLE": "Road", "FISHINGER": "Boulevard", "ANSON": "Drive", "COSGRAY": "Road",
    "BROWN PARK": "Drive", "HERITAGE CLUB": "Drive", "NORTHWEST": "Parkway", "LUTHER": "Lane", "COLUMBIA": "Street",
    "WALLINGTON": "Drive", "FRANKLIN": "Street", "MADISON": "Street", "WEAVER": "Court", "WOODS MILL": "Drive",
    "BRITTON FARMS": "Drive", "HYDE PARK": "Drive", "ELLIOTT": "Road", "REYNOLDS": "Road", "PARK MILL RUN": "Drive", "CENTER": "Street",
    "WAYNE": "Street", "FRAZELL": "Road", "COLLIER HILL": "Drive", "PAXTON": "Drive", "FARBER ROW": "Lane", "PLANK": "Street",
    "MARBLE CLIFF": "Road", "AUDUBON": "Lane", "BLUE HERON": "Drive", "PRAIRIE ROSE": "Drive", "WAKEFIELD": "Drive",
    "DAVID MEEKS": "Drive", "SCIOTO DARBY CREEK": "Road", "NOOR": "Pike", "VETERANS MEMORIAL": "Drive", "JEANNETTE": "Drive",
    "KRIGGSBY": "Boulevard", "HEATHER RIDGE": "Drive", "SUTTER HOME": "Drive", "SPRINGDALE": "Drive", "JEFFRELYN": "Drive",
    "BRADFORD": "Drive", "CAVALIER": "Drive", "HOFFMAN FARMS": "Drive", "WHISPERING OAK": "Boulevard", "LATTIMER": "Drive",
    "DEXTER": "Drive", "BRONSON": "Road", "GRACE": "Drive", "LUXAIR": "Drive", "FAIRWAY COMMONS": "Drive", "WOODSVIEW": "Way",
    "ELWOOD": "Drive", "ALTON DARBY": "Road", "WALKER": "Road", "RENNER": "Road", "FEDER": "Road", "SPINDLER": "Road",
    "I-270": "", "I-270 RAMP": "", "ALTON": "Road", "HILLIARD CEMETERY": "Road", "OLD HILLIARD CEMETERY": "Road",
    "LAKEVIEW": "Drive", "SCHIRTZINGER": "Road", "ADA": "Lane", "SHIER RINGS": "Road", "HILLIARD GREEN": "Drive", "LYMAN DRIVE": "Drive",
    "HOMESTEAD": "Drive", "TRUEMAN BLVD": "Boulevard", "BRITTON PKWY": "Parkway", "CEMETERY RD": "Road", "HILLIARD ROME RD": "Road",
}
# aliases that OCR / officers produce for the same road
ALIAS = {"TINEAPPLE": "TINAPPLE", "DAVICSON": "DAVIDSON", "YMAN": "LYMAN", "AUDOBON": "AUDUBON", "HILLIARD & ROME": "HILLIARD ROME",
         "ROME HILLIARD": "HILLIARD ROME", "HILLIARD-ROME": "HILLIARD ROME", "MAIN STREET": "MAIN", "WAKEFIELD DRIVE": "WAKEFIELD",
         "TRUEMAN BLVD": "TRUEMAN", "BRITTON PKWY": "BRITTON", "CEMETERY RD": "CEMETERY", "HILLIARD ROME RD": "HILLIARD ROME",
         "LYMAN DRIVE": "LYMAN", "I270": "I-270", "I 270": "I-270", "270": "I-270", "ALTON DARBY CREEK RD": "ALTON DARBY CREEK"}
SUFFIX = {"RD", "ROAD", "DR", "DRIVE", "ST", "STREET", "BLVD", "BOULEVARD", "PKWY", "PARKWAY", "LN", "LANE", "CT", "COURT", "AVE",
          "AVENUE", "WAY", "PL", "PLACE", "CIR", "CIRCLE", "PIKE", "TRL", "TRAIL", "HWY"}
TYPES = {"AL": "Alley", "AV": "Avenue", "BL": "Boulevard", "CR": "Circle", "CT": "Court", "DR": "Drive", "HE": "Heights", "HW": "Highway",
         "LA": "Lane", "MP": "Milepost", "OV": "Oval", "PK": "Parkway", "PI": "Pike", "PL": "Place", "RD": "Road", "SQ": "Square",
         "ST": "Street", "TE": "Terrace", "TL": "Trail", "WA": "Way"}
KEYS = list(CANON)

def clean(name):
    n = (name or "").upper().replace("—", " ").replace("-", " ")
    n = re.sub(r"[^A-Z0-9 &]", " ", n)
    toks = [t for t in n.split() if t]
    # drop OCR junk tokens (1-2 letters that are not a real word, stray digits glued on)
    while toks and (re.fullmatch(r"[A-Z]{1,2}", toks[-1]) and toks[-1] not in ("I",) or re.fullmatch(r"\d", toks[-1]) or toks[-1] in SUFFIX):
        toks.pop()
    while toks and re.fullmatch(r"[A-Z]{1,2}", toks[0]) and toks[0] not in ("I",):
        toks.pop(0)
    n = " ".join(toks).replace("I 270", "I-270")
    return ALIAS.get(n, n)

def canonical(name):
    """returns (canonical name in title case, type word) or (cleaned name, '') when unknown"""
    n = clean(name)
    if not n: return "", ""
    if n in CANON: return n.title().replace("I-270", "I-270"), CANON[n]
    m = difflib.get_close_matches(n, KEYS, n=1, cutoff=0.8)
    if m: return m[0].title(), CANON[m[0]]
    # two-word names where one word matched a canonical road (e.g. "CEMETERY 7", "TRUEMAN IL" already cleaned)
    for k in KEYS:
        if len(k) >= 5 and n.startswith(k + " "): return k.title(), CANON[k]
    return n.title(), ""

def fix_crash(c):
    for side in ("location", "reference"):
        raw = c.get(f"{side}_road_name") or ""
        if re.fullmatch(r"\s*\d{2,6}\s*", raw):                   # a house number as reference
            c[f"{side}_road"] = raw.strip(); c[f"{side}_road_name"] = raw.strip(); continue
        name, typ = canonical(raw)
        if not typ:
            t = (c.get(f"{side}_road_type") or "").upper()[:2]
            typ = TYPES.get(t, "")
        c[f"{side}_road_name"] = name
        c[f"{side}_road"] = (name + (" " + typ if typ and name else "")).strip()
    # OCR misreads a "1" into injury codes: a fatality only counts when the crash itself is coded fatal
    if c.get("severity_code") == 1:
        c["fatal_count"] = max(1, c.get("fatal_count") or 0)
    else:
        c["fatal_count"] = 0
        for p in c.get("persons", []):
            if p.get("injury_code") == 1:
                p["injury_code"] = None; p["injury"] = None
    # OCR'd drug checkboxes have a high false-positive rate: on scans require corroboration from the condition / test fields
    if c.get("source_type") == "scan" and c.get("drug_suspected"):
        drivers = [p for p in c.get("persons", []) if str(p.get("role", "")).startswith("Driver")]
        corroborated = any(p.get("condition") == "Under the influence of medications/drugs/alcohol" or
                           (p.get("drug_test_status") not in (None, "None given")) for p in drivers)
        if not corroborated:
            c["drug_suspected"] = False
            for p in drivers:
                p["marijuana_suspected"] = False; p["other_drug_suspected"] = False
    return c

def main():
    path = sys.argv[1]
    with open(path) as f: blob = json.load(f)
    for c in blob["crashes"]: fix_crash(c)
    with open(path, "w") as f: json.dump(blob, f, separators=(",", ":"))
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import oh1_extract as T
    T.write_outputs(blob["crashes"], os.path.dirname(path) or ".")
    with open(path, "w") as f: json.dump(blob, f, separators=(",", ":"))
    print(len(blob["crashes"]), "crashes normalised")

if __name__ == "__main__":
    main()
