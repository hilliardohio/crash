# Hilliard Traffic Crash Dashboard

A static, GitHub-Pages-ready dashboard that maps crashes from Hilliard Police **OH-1 Traffic Crash Reports** and runs basic reports on them (time of day, driver age, conditions, hot spots, and more). Same pattern as the utility meter map in `hilliardohio/bills`: one `index.html` plus a data file.

```
crash-dashboard/
├── index.html            the dashboard (map + filters + report builder + hot spots)
├── vendor/               Leaflet 1.9.4, leaflet.heat, Chart.js 4.4.1 (no CDN needed)
├── data/
│   ├── crashes.json      what the page loads — produced by oh1_extract.py
│   ├── crashes.csv       flat one-row-per-crash export (same data, for Excel)
│   ├── persons.csv       one row per driver / occupant (age, gender, injury, belts, …)
│   └── sample.json       420 SYNTHETIC crashes for previewing the page (?data=data/sample.json)
├── oh1_extract.py        text-layer (RMS export) extractor
├── oh1_ocr_extract.py    OCR / flattened-form extractor (uses digit_templates.json)
├── batch_worker.py       resumable batch runner (scan / repair / assemble)
├── roadnames.py          road-name normalisation
├── digit_templates.json  glyph templates for the form's digit fonts
└── make_sample_data.py   regenerates sample.json (not needed in production)
```

## 1. Turn OH-1 PDFs into data

Requires Python 3 with `pip install pdfplumber pytesseract pillow numpy`, plus the `tesseract` and `pdftoppm` (poppler) command-line tools for scanned reports.

Three kinds of OH-1 PDF turn up in the City's files, and the tools handle all three:

| kind | how it is read | script |
|---|---|---|
| RMS export with a text layer (SSRS "CrashOH1M5", e.g. the 2026 files) | positions of the text on the page | `oh1_extract.py` |
| flattened fillable form with a text layer (iText, many 2021 files) | positions of the text on the page | `oh1_ocr_extract.py` (vector path) |
| scanned printout, image only (most 2020–2025 files) | rendered at 200 dpi and OCR'd: tesseract for labels/text, a template matcher trained on the form's digit fonts for the coded boxes, ink measurement for checkboxes | `oh1_ocr_extract.py` |

For a handful of files:

```bash
python3 oh1_ocr_extract.py reports/2026 -o data --merge     # any mix of the three kinds
```

For the whole archive (hundreds of scans take ~15 s each), use the resumable batch runner — it can be stopped and restarted at any time and remembers what is done:

```bash
python3 batch_worker.py scan "Crash Reports" --work work          # parse everything (re-run to continue)
python3 batch_worker.py repair "Crash Reports" --work work        # re-read the crash page of scans missing a date/coordinates
python3 batch_worker.py assemble --work work -o data              # write data/crashes.json, crashes.csv, persons.csv
```

`assemble` also runs `roadnames.py`, which snaps OCR'd street names to a canonical Hilliard road list (edit `CANON` in that file to add roads) so hot-spot counts add up.

Options: `--keep-report-number` publishes the local report number as the id (by default it is a short hash so the public file cannot be joined back to a specific report); `--merge` keeps crashes already in `data/crashes.json`; `--shard i/n` and `--time-budget SEC` let the batch runner be split across processes or capped per run.

### What is extracted (and what is not)

Extracted from each report: date/time, lat/long, road + cross street / house number, reference point and distance, severity, manner of collision, light, weather, road condition, surface, contour, intersection/interchange flags, work zone and school zone flags, hit/skip, private property, narrative, reported/dispatch/arrival/cleared times, roadway-closed minutes; per unit: unit type, damage, vehicle year/make/model, occupants, pre-crash action, contributing circumstance, traffic control, posted and estimated speed, sequence of events; per person: role, unit, **age, gender**, injury, EMS/facility, safety equipment, seating, air bag, ejection, OL class, distraction, alcohol/drug suspected, test status/type/value, offense charged and description.

**Never written to any output:** names, dates of birth, addresses, phone numbers, license plates, VINs, insurance company/policy, operator license numbers, citation numbers, owner and carrier names, towing company, officer names and badge numbers.

Derived fields the dashboard uses: `hour`, `day_of_week`, `month`, `year`, `unit_in_error_driver_age` / `_age_band` / `_gender` (the driver of the unit marked *Unit in Error*), `primary_contributing_circumstance`, `alcohol_suspected`, `drug_suspected`, `distracted`, `citation_issued`, `injured_count`, `fatal_count`, `pedestrian_or_bicycle`, `motorcycle`, `response_minutes`, `source_type` (text / vector / scan).

### Accuracy of the OCR'd (scanned) reports

Text-layer reports are exact. Scanned reports are good but not perfect: on the 2020–2026 archive about 86% came back with usable coordinates, 88% with a date/time, 98% with a severity, and 77% with the at-fault driver's age. The weakest group is the **handwritten** reports (most of 2020 and part of 2021), where the coded boxes are mostly unreadable; those crashes still appear in the data with whatever could be read (often the narrative and the roads), but without a map point. A few conventions in the OCR output: coordinates are forced to Hilliard's 40.xxxxxx / -83.xxxxxx, a crash is counted as fatal only when the report's severity says so, and drug-suspected flags on scans need corroboration from the condition or test fields (the checkbox reads produced false positives). `crashes.json` carries `source_type` on every record so you can filter to the exact ones when precision matters.

## 2. Preview locally

Browsers will not `fetch()` a JSON file from `file://`, so serve the folder:

```bash
python3 -m http.server 8000
# open http://localhost:8000/            → real data (data/crashes.json)
# open http://localhost:8000/?data=data/sample.json   → synthetic preview
```

## 3. Publish on GitHub Pages

1. Create a repo under the `hilliardohio` account (e.g. `crashes`) and upload everything except `make_sample_data.py` (and `data/sample.json`, once real data exists).
2. Settings → Pages → *Deploy from a branch* → `main` / root.
3. The page is live at `https://hilliardohio.github.io/crashes/`.

Updating: re-run the extractor and commit the new `data/crashes.json` (the CSVs are optional but handy for Excel users). Nothing in `index.html` needs to change.

## Using the dashboard

* **Filters** (date range, severity, light, weather, road condition, manner, at-fault driver age, day of week, road search, and flag chips for alcohol, drugs, distracted, in-intersection, ped/bike, motorcycle, cited, hit/skip) apply to everything on the page at once.
* **Map** — markers colored by severity, sized by persons injured; click for the crash details and narrative. *Heat map* toggles a density layer; *Fit to results* re-zooms as filters change. Clicking a row in the crash list or the hot-spot table flies the map there.
* **Report builder** — choose a field to count crashes by (hour of day, day of week, month, year, driver age band, gender, light, weather, road condition, manner, contributing circumstance, unit type, road, road + cross street, …) and optionally split it by a second field (severity, gender, light, weather, alcohol, intersection, year, day of week, age band). Download the table as CSV.
* **Hot spots** — top 25 road / cross-street combinations with injury, fatal and alcohol counts.
* **Crashes in view** — sortable list of the filtered crashes with CSV download.

The page respects the viewer's light/dark system setting.
